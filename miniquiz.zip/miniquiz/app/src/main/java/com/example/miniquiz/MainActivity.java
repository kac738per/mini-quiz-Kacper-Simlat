package com.example.miniquiz;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;

public class MainActivity extends AppCompatActivity {

    TextView titleText, questionText, scoreText;
    Button startButton, aBtn, bBtn, cBtn, resetButton;

    ArrayList<Question> questions = new ArrayList<>();
    int currentIndex = 0;
    int score = 0;

    ArrayList<Question> selectedQuestions = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        titleText = findViewById(R.id.titleText);
        questionText = findViewById(R.id.questionText);
        scoreText = findViewById(R.id.scoreText);

        startButton = findViewById(R.id.startButton);
        aBtn = findViewById(R.id.answerA);
        bBtn = findViewById(R.id.answerB);
        cBtn = findViewById(R.id.answerC);
        resetButton = findViewById(R.id.resetButton);

        loadQuestions();

        startButton.setOnClickListener(v -> startQuiz());

        aBtn.setOnClickListener(v -> checkAnswer(aBtn.getText().toString()));
        bBtn.setOnClickListener(v -> checkAnswer(bBtn.getText().toString()));
        cBtn.setOnClickListener(v -> checkAnswer(cBtn.getText().toString()));

        resetButton.setOnClickListener(v -> resetQuiz());
    }

    private void loadQuestions() {
        questions.add(new Question("Stolica Włoch to:", "Rzym", "Paryż", "Madryt", "Rzym"));
        questions.add(new Question("Ile nóg ma pająk?", "6", "8", "10", "8"));
        questions.add(new Question("Największa planeta to:", "Mars", "Ziemia", "Jowisz", "Jowisz"));
        questions.add(new Question("2 + 2 * 2 =", "6", "8", "4", "6"));
        questions.add(new Question("Kolor liści latem:", "Czerwony", "Zielony", "Niebieski", "Zielony"));
        questions.add(new Question("Stolica Polski:", "Kraków", "Warszawa", "Gdańsk", "Warszawa"));
    }

    private void startQuiz() {
        score = 0;
        currentIndex = 0;
        scoreText.setText("Wynik: 0");

        Collections.shuffle(questions);
        selectedQuestions = new ArrayList<>(questions.subList(0, 5));

        showQuestion(currentIndex);

        startButton.setVisibility(View.GONE);
        questionText.setVisibility(View.VISIBLE);
        aBtn.setVisibility(View.VISIBLE);
        bBtn.setVisibility(View.VISIBLE);
        cBtn.setVisibility(View.VISIBLE);
    }

    private void showQuestion(int index) {
        Question q = selectedQuestions.get(index);

        questionText.setText(q.getText());
        aBtn.setText(q.getAnswerA());
        bBtn.setText(q.getAnswerB());
        cBtn.setText(q.getAnswerC());
    }

    private void checkAnswer(String answer) {
        Question q = selectedQuestions.get(currentIndex);

        if (answer.equals(q.getCorrect())) {
            score++;
            scoreText.setText("Wynik: " + score);
        }

        currentIndex++;

        if (currentIndex < selectedQuestions.size()) {
            showQuestion(currentIndex);
        } else {
            Toast.makeText(this, "Koniec quizu! Twój wynik: " + score + "/5", Toast.LENGTH_LONG).show();
            startButton.setVisibility(View.VISIBLE);
        }
    }

    private void resetQuiz() {
        score = 0;
        currentIndex = 0;

        scoreText.setText("Wynik: 0");
        questionText.setVisibility(View.GONE);
        aBtn.setVisibility(View.GONE);
        bBtn.setVisibility(View.GONE);
        cBtn.setVisibility(View.GONE);

        startButton.setVisibility(View.VISIBLE);
    }
}
